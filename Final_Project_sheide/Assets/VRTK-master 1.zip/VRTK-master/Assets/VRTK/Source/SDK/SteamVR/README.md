# SteamVR

## Instructions for using SteamVR

 * Import the [SteamVR 1.2.3 Plugin](https://github.com/ValveSoftware/steamvr_unity_plugin/releases/download/1.2.3/SteamVR.Plugin.unitypackage) from GitHub.
 * Follow the initial [Getting Started](/Assets/VRTK/Documentation/GETTING_STARTED.md) steps and then add the `[CameraRig]` prefab from the [SteamVR 1.2.3 Plugin](https://github.com/ValveSoftware/steamvr_unity_plugin/releases/download/1.2.3/SteamVR.Plugin.unitypackage) as a child of the SDK Setup GameObject.
