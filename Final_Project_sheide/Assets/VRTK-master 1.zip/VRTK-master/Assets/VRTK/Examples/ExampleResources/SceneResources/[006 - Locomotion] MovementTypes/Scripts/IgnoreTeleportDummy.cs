﻿namespace VRTK.Examples
{
    using UnityEngine;

    public class IgnoreTeleportDummy : MonoBehaviour
    {
    }
}